import termdraw
import time
import curses
import random
from classes import *

field_map = []

last_time = time.time()
last_dir = "up"
timer= 1

snake = Snake(10, 10)
apple = Apple()
def draw_fields(fields):
    ret = []
    
    for x in range(len(fields)):
        ret.append([])
        for y in range(len(fields[x])):
            field = fields[x][y]
            ret[x].append("")
        
            if field.type == "apple":
                ret[x][y] = "apple"
            elif field.type == "snake":
                ret[x][y] = "snake"
            elif field.type == "head":
                ret[x][y] = "head"
            else:
                ret[x][y] = "empty"

    return ret

def clean_fields(fields):
    for x in fields:
        for y in x:
            y.type = "empty"
    return fields

def mainloop():
    global timer
    global last_time
    global last_dir
    timer += time.time() - last_time
    last_time = time.time()
    #termdraw.f.write(termdraw.read_input())
    inp = termdraw.read_input()
    if inp == curses.KEY_UP and last_dir != "down":
        snake.dir = "up"
    elif inp == curses.KEY_RIGHT and last_dir != "left":
        snake.dir = "right"
    elif inp == curses.KEY_DOWN and last_dir != "up":
        snake.dir = "down"
    elif inp == curses.KEY_LEFT and last_dir != "right":
        snake.dir = "left"

    if apple.x == snake.x and snake.y == apple.y:
        termdraw.stdscr.addstr(10, 39, "Consumed")
        apple.consume()
        snake.add_apple = True
    else:
        termdraw.stdscr.addstr(10, 39, "         ")
    
    #termdraw.stdscr.addstr(10, 40, str(timer))
    
    if timer > 0.2:
        last_dir = snake.dir
        if not snake.move():
            return False
        else:
            timer = 0
            return True
        #termdraw.f.write(str(field_map))
    return True        

if __name__ == "__main__":
    for x in range(bounds[0]):
        field_map.append([])
        for y in range(bounds[1]):
            field_map[x].append(Field(x, y))

    try:
        termdraw.start()
        termdraw.draw_box()
        snake.draw(field_map)
        while True:
            if not mainloop(): break

            field_map = clean_fields(field_map)
            apple.draw(field_map)
            snake.draw(field_map)
            termdraw.draw_screen(draw_fields(field_map))
            termdraw.refresh()
    finally:
        termdraw.end()

